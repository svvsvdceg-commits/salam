<header class="topbar">
    <div class="container header">
        <a href="<?php echo e(route('home')); ?>" class="logo">ОКТА<span>ГОН</span><small>Новости UFC и MMA</small></a>
        <nav aria-label="Основное меню">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>">Главная</a>
            <details class="category-menu">
                <summary class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('category')]); ?>">Категории</summary>
                <div class="category-menu-items">
                    <?php $__currentLoopData = $navigationCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('category', $section->slug)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => in_array(request()->route('category'), [$section->slug, $section->name], true)]); ?>"><?php echo e($section->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </details>
            <?php if(auth()->guard()->check()): ?>
                <?php if(in_array(auth()->user()->role, ['journalist', 'admin'], true)): ?>
                    <a href="<?php echo e(route('journalist.create')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['staff-link', 'active' => request()->routeIs('journalist.*')]); ?>">Журналист</a>
                <?php endif; ?>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['staff-link', 'active' => request()->routeIs('admin.*')]); ?>">Админ</a>
                <?php endif; ?>
                <span class="account-name"><?php echo e(auth()->user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="logout-button" type="submit">Выйти</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('login')]); ?>">Войти</a>
                <a href="<?php echo e(route('register')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('register')]); ?>">Регистрация</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<?php /**PATH C:\Users\krasn\OneDrive\Desktop\ufc\resources\views/partials/header.blade.php ENDPATH**/ ?>