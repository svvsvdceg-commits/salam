<?php $__env->startSection('title', 'Регистрация — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page auth-page">
        <h1>Регистрация</h1>
        <p class="page-intro">Создайте аккаунт Октагона.</p>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form action="<?php echo e(route('register')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label for="name">Имя</label>
                <input id="name" name="name" value="<?php echo e(old('name')); ?>" maxlength="255" autocomplete="name" required autofocus>
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" maxlength="255" autocomplete="username" required>
            </div>
            <div class="field">
                <label for="password">Пароль (не менее 8 символов)</label>
                <input id="password" type="password" name="password" minlength="8" autocomplete="new-password" required>
            </div>
            <div class="field">
                <label for="password_confirmation">Повторите пароль</label>
                <input id="password_confirmation" type="password" name="password_confirmation" minlength="8" autocomplete="new-password" required>
            </div>
            <button type="submit">Зарегистрироваться</button>
        </form>
        <p class="auth-switch">Уже есть аккаунт? <a href="<?php echo e(route('login')); ?>">Войти</a></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\ufc\resources\views/auth/register.blade.php ENDPATH**/ ?>