<?php $__env->startSection('title', 'Вход — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page auth-page">
        <h1>Вход в аккаунт</h1>
        <p class="page-intro">Войдите в свой аккаунт Октагона.</p>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
            </div>
            <div class="field">
                <label for="password">Пароль</label>
                <input id="password" type="password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit">Войти</button>
        </form>
        <p class="auth-switch">Нет аккаунта? <a href="<?php echo e(route('register')); ?>">Зарегистрироваться</a></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\ufc\resources\views/auth/login.blade.php ENDPATH**/ ?>