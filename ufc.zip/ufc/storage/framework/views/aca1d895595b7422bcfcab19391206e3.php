<footer>
    <div class="container footer-inner">
        <div><strong>Октагон</strong><p>Поединки, бойцы и новости смешанных единоборств.</p></div>
        <span>© <?php echo e(date('Y')); ?> · Новости UFC и MMA</span>
    </div>
</footer>
<?php /**PATH C:\Users\krasn\OneDrive\Desktop\ufc\resources\views/partials/footer.blade.php ENDPATH**/ ?>