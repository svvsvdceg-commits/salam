<div class="field">
    <label for="title">Заголовок новости</label>
    <input id="title" name="title" type="text" value="{{ old('title', $article?->title) }}" required maxlength="255">
</div>
<div class="field">
    <label for="category">Категория</label>
    <select id="category" name="category" required>
        <option value="">Выберите категорию</option>
        @php($selectedCategory = old('category', $article?->category))
        @if ($selectedCategory && !in_array($selectedCategory, \App\Models\Article::CATEGORIES, true))
            <option value="{{ $selectedCategory }}" selected>{{ $selectedCategory }} (прежняя категория)</option>
        @endif
        @foreach (\App\Models\Article::CATEGORIES as $category)
            <option value="{{ $category }}" @selected($selectedCategory === $category)>{{ $category }}</option>
        @endforeach
    </select>
</div>
<div class="field">
    <label for="image">Ссылка на изображение (необязательно)</label>
    <input id="image" name="image" type="url" value="{{ old('image', $article?->image) }}" maxlength="255" placeholder="https://…">
</div>
<div class="field">
    <label for="image_file">Загрузить фотографию с компьютера</label>
    <input id="image_file" name="image_file" type="file" accept="image/jpeg,image/png,image/gif,image/webp" aria-describedby="image-help">
    <p id="image-help" class="muted">JPG, PNG, GIF или WebP, до 5 МБ. Файл используется вместо ссылки. Чтобы сохранить фотографию, оставьте это поле пустым и не меняйте ссылку.</p>
    @if ($article?->image_url)
        <img class="article-image" src="{{ $article->image_url }}" alt="Текущая фотография новости">
    @endif
</div>
<div class="field">
    <label for="excerpt">Краткое описание</label>
    <textarea id="excerpt" name="excerpt" rows="3">{{ old('excerpt', $article?->excerpt) }}</textarea>
</div>
<div class="field">
    <label for="content">Полный текст новости</label>
    <textarea id="content" name="content" rows="8" required>{{ old('content', $article?->content) }}</textarea>
</div>
