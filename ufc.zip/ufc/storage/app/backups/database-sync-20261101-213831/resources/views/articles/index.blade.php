@extends('layouts.app')
@section('title', ($category ?? 'Главная') . ' — Октагон')
@section('content')
    @include('partials.notices')
    <section class="hero">
        <div class="hero-copy">
            <div class="hero-label">UFC · Смешанные единоборства</div>
            <h1>Всё, что происходит в октагоне.</h1>
            <p>Новости поединков, истории бойцов и события мира MMA. Выберите раздел или найдите нужную статью.</p>
        </div>
        <img class="hero-image" src="{{ asset('images/ufc-champions.jpg') }}" alt="Бойцы UFC с чемпионскими поясами">
    </section>
    @php($listingUrl = isset($category) ? route('category', $category) : route('home'))
    <form action="{{ $listingUrl }}" method="GET" class="search-form" role="search">
        <input type="search" name="search" aria-label="Поиск новостей по заголовку" placeholder="Найти новость по заголовку…" value="{{ $search }}">
        <button type="submit">Найти</button>
        @if ($search !== '')
            <a href="{{ $listingUrl }}">Сбросить</a>
        @endif
    </form>
    <div class="section-heading">
        <h2>{{ $category ?? 'Последние новости' }}</h2>
        <span class="muted">{{ $search !== '' ? 'Найдено' : 'Материалов' }}: {{ $articles->count() }}</span>
    </div>
    <div class="news-grid">
        @forelse ($articles as $article)
            <a class="news-card" href="{{ route('article.show', $article->slug) }}">
                <img class="news-image" loading="lazy" src="{{ $article->image_url ?: asset('images/' . ($article->category === 'Бойцы' ? 'ufc-fighter.jpg' : 'ufc-fight.jpg')) }}" alt="{{ $article->title }}">
                <div class="news-content">
                    <span class="category-tag">{{ $article->category }}</span>
                    <h3>{{ $article->title }}</h3>
                    <p>{{ $article->excerpt ?: \Illuminate\Support\Str::limit($article->content, 120) }}</p>
                    <div class="news-meta">{{ $article->author_name }} · {{ ($article->published_at ?? $article->created_at)->format('d.m.Y') }}</div>
                </div>
            </a>
        @empty
            <div class="empty">
                <h3>{{ $search !== '' ? 'Ничего не найдено' : 'Пока нет новостей' }}</h3>
                <p>{{ $search !== '' ? 'Попробуйте другое слово или сбросьте поиск.' : 'Новые материалы появятся здесь после публикации.' }}</p>
            </div>
        @endforelse
    </div>
@endsection
