<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index(Request $request)
    {
        return $this->listing($request);
    }

    public function category(Request $request, string $category)
    {
        return $this->listing($request, $category);
    }

    private function listing(Request $request, ?string $category = null)
    {
        $validated = $request->validate(['search' => 'nullable|string|max:255']);
        $search = trim($validated['search'] ?? '');
        $articles = Article::with('user')->where('is_published', true)
            ->when($category !== null, fn ($query) => $query->where('category', $category))
            ->when($search !== '', fn ($query) => $query->where('title', 'like', '%'.$search.'%'))
            ->orderByRaw('COALESCE(published_at, created_at) DESC')
            ->orderByDesc('id')
            ->get();

        return view('articles.index', compact('articles', 'search', 'category'));
    }

    public function show(string $slug)
    {
        $article = Article::with('user')->where('slug', $slug)
            ->where('is_published', true)
            ->firstOrFail();

        return view('articles.show', compact('article'));
    }
}
