<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    public function index()
    {
        $articles = Article::with('user')->latest()->get();

        return view('admin.index', compact('articles'));
    }

    public function edit(Article $article)
    {
        return view('admin.edit', compact('article'));
    }

    public function update(Request $request, Article $article)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'image' => 'nullable|url|max:255',
            'image_file' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp|max:5120',
            'excerpt' => 'nullable|string',
            'content' => 'required|string',
        ]);

        $previousImagePath = $article->image_path;
        $imagePath = $previousImagePath;
        if ($request->hasFile('image_file')) {
            $imagePath = $request->file('image_file')->store('articles', 'public');
        } elseif (($validated['image'] ?? null) !== $article->image) {
            $imagePath = null;
        }

        $article->update([
            'title' => $validated['title'],
            'slug' => Str::slug($validated['title']).'-'.$article->id,
            'category' => $validated['category'],
            'image' => $validated['image'] ?? null,
            'image_path' => $imagePath,
            'excerpt' => $validated['excerpt'] ?? null,
            'content' => $validated['content'],
        ]);

        if ($previousImagePath && $previousImagePath !== $imagePath) {
            Storage::disk('public')->delete($previousImagePath);
        }

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость успешно обновлена.');
    }

    public function togglePublication(Article $article)
    {
        $article->is_published = ! $article->is_published;
        if ($article->is_published && ! $article->published_at) {
            $article->published_at = now();
        }
        $article->save();

        return redirect()
            ->route('admin.index')
            ->with('success', 'Статус публикации изменён.');
    }

    public function destroy(Article $article)
    {
        $imagePath = $article->image_path;
        $article->delete();
        if ($imagePath) {
            Storage::disk('public')->delete($imagePath);
        }

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость удалена.');
    }
}
