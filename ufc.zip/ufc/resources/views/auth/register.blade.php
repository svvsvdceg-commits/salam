@extends('layouts.app')
@section('title', 'Регистрация — Октагон')
@section('content')
    <div class="article-page auth-page">
        <h1>Регистрация</h1>
        <p class="page-intro">Создайте аккаунт Октагона.</p>
        @include('partials.notices')
        <form action="{{ route('register') }}" method="POST">
            @csrf
            <div class="field">
                <label for="name">Имя</label>
                <input id="name" name="name" value="{{ old('name') }}" maxlength="255" autocomplete="name" required autofocus>
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" maxlength="255" autocomplete="username" required>
            </div>
            <div class="field">
                <label for="password">Пароль (не менее 8 символов)</label>
                <input id="password" type="password" name="password" minlength="8" autocomplete="new-password" required>
            </div>
            <div class="field">
                <label for="password_confirmation">Повторите пароль</label>
                <input id="password_confirmation" type="password" name="password_confirmation" minlength="8" autocomplete="new-password" required>
            </div>
            <button type="submit">Зарегистрироваться</button>
        </form>
        <p class="auth-switch">Уже есть аккаунт? <a href="{{ route('login') }}">Войти</a></p>
    </div>
@endsection
