@extends('layouts.app')
@section('title', 'Вход — Октагон')
@section('content')
    <div class="article-page auth-page">
        <h1>Вход в аккаунт</h1>
        <p class="page-intro">Войдите в свой аккаунт Октагона.</p>
        @include('partials.notices')
        <form action="{{ route('login') }}" method="POST">
            @csrf
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" autocomplete="username" required autofocus>
            </div>
            <div class="field">
                <label for="password">Пароль</label>
                <input id="password" type="password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit">Войти</button>
        </form>
        <p class="auth-switch">Нет аккаунта? <a href="{{ route('register') }}">Зарегистрироваться</a></p>
    </div>
@endsection
