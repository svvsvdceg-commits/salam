@extends('layouts.app')
@section('title', 'Журналист — Октагон')
@section('content')
    <div class="article-page">
        <h1>Добавить новость</h1>
        <p class="page-intro">Напишите о поединке, бойце или событии UFC.</p>
        @include('partials.notices')
        <form action="{{ route('journalist.store') }}" method="POST">
            @csrf
            @include('partials.article-fields', ['article' => null])
            <button type="submit">Опубликовать новость</button>
        </form>
    </div>
    <section class="added-news">
        <h2>Добавленные новости</h2>
        @forelse ($articles as $article)
            <div class="manage-item">
                <h3>{{ $article->title }}</h3>
                <p class="muted">{{ $article->category }} · {{ $article->created_at->format('d.m.Y') }} · {{ $article->is_published ? 'Опубликована' : 'Заблокирована' }}</p>
                <div class="actions">
                    @if ($article->is_published)
                        <a href="{{ route('article.show', $article->slug) }}">Открыть новость</a>
                    @else
                        <span class="muted">Публикация скрыта</span>
                    @endif
                    @if (auth()->user()->role === 'admin')
                        <a href="{{ route('admin.articles.edit', $article) }}">Редактировать</a>
                    @endif
                </div>
            </div>
        @empty
            <div class="empty"><p>Пока нет добавленных новостей.</p></div>
        @endforelse
    </section>
@endsection
