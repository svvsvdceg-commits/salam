@extends('layouts.app')
@section('title', 'Редактирование новости — Октагон')
@section('content')
    <div class="article-page">
        <a href="{{ route('admin.index') }}">← Назад в админку</a>
        <h1>Редактировать новость</h1>
        @include('partials.notices')
        <form action="{{ route('admin.articles.update', $article) }}" method="POST">
            @csrf
            @method('PUT')
            @include('partials.article-fields', ['article' => $article])
            <button type="submit">Сохранить изменения</button>
        </form>
    </div>
@endsection
