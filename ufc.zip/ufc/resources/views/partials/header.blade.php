<header class="topbar">
    <div class="container header">
        <a href="{{ route('home') }}" class="logo">ОКТА<span>ГОН</span><small>Новости UFC и MMA</small></a>
        <nav aria-label="Основное меню">
            <a href="{{ route('home') }}" @class(['active' => request()->routeIs('home')])>Главная</a>
            <details class="category-menu">
                <summary @class(['active' => request()->routeIs('category')])>Категории</summary>
                <div class="category-menu-items">
                    @foreach ($navigationCategories as $section)
                        <a href="{{ route('category', $section->slug) }}" @class(['active' => in_array(request()->route('category'), [$section->slug, $section->name], true)])>{{ $section->name }}</a>
                    @endforeach
                </div>
            </details>
            @auth
                @if (in_array(auth()->user()->role, ['journalist', 'admin'], true))
                    <a href="{{ route('journalist.create') }}" @class(['staff-link', 'active' => request()->routeIs('journalist.*')])>Журналист</a>
                @endif
                @if (auth()->user()->role === 'admin')
                    <a href="{{ route('admin.index') }}" @class(['staff-link', 'active' => request()->routeIs('admin.*')])>Админ</a>
                @endif
                <span class="account-name">{{ auth()->user()->name }}</span>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button class="logout-button" type="submit">Выйти</button>
                </form>
            @else
                <a href="{{ route('login') }}" @class(['active' => request()->routeIs('login')])>Войти</a>
                <a href="{{ route('register') }}" @class(['active' => request()->routeIs('register')])>Регистрация</a>
            @endauth
        </nav>
    </div>
</header>
