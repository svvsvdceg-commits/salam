<footer>
    <div class="container footer-inner">
        <div><strong>Октагон</strong><p>Поединки, бойцы и новости смешанных единоборств.</p></div>
        <span>© {{ date('Y') }} · Новости UFC и MMA</span>
    </div>
</footer>
