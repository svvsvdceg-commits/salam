param([string]$AdminEmail)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$phpCommand = Get-Command php -ErrorAction SilentlyContinue
$phpPath = if ($phpCommand) { $phpCommand.Source } else { Join-Path $env:USERPROFILE '.config\herd-lite\bin\php.exe' }
if (-not (Test-Path -LiteralPath $phpPath)) {
    throw 'PHP не найден. Установите PHP 8.3 или новее.'
}
$env:Path = (Split-Path -Parent $phpPath) + ';' + $env:Path

# Отдельная база для просмотра. Настройки и данные MySQL не меняются.
$previewDatabase = Join-Path $PSScriptRoot 'storage\app\ufc-preview.sqlite'
if (-not (Test-Path -LiteralPath $previewDatabase)) {
    New-Item -ItemType File -Path $previewDatabase | Out-Null
}
$env:DB_CONNECTION = 'sqlite'
$env:DB_DATABASE = $previewDatabase
$env:DB_URL = ''
$env:SESSION_DRIVER = 'file'
$env:CACHE_STORE = 'file'
$env:QUEUE_CONNECTION = 'sync'

& $phpPath artisan migrate --force
if ($LASTEXITCODE -ne 0) { throw 'Не удалось подготовить базу предпросмотра.' }
if ($AdminEmail) {
    & $phpPath artisan ufc:promote $AdminEmail
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось назначить администратора. Сначала зарегистрируйтесь в базе предпросмотра.' }
}
& $phpPath artisan db:seed --class=UfcDemoSeeder --force
if ($LASTEXITCODE -ne 0) { throw 'Не удалось добавить демонстрационные материалы.' }
Write-Host 'Октагон: http://127.0.0.1:8011 — для остановки нажмите Ctrl+C'
& $phpPath artisan serve --host=127.0.0.1 --port=8011
