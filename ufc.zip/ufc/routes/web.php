<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\JournalistController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ArticleController::class, 'index'])->name('home');

Route::get('/category/{category}', [ArticleController::class, 'category'])
    ->name('category');

Route::get('/article/{slug}', [ArticleController::class, 'show'])
    ->name('article.show');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:6,1');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth', 'journalist'])->group(function () {
    Route::get('/journalist', [JournalistController::class, 'create'])
        ->name('journalist.create');

    Route::post('/journalist', [JournalistController::class, 'store'])
        ->name('journalist.store');
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/admin', [AdminController::class, 'index'])
        ->name('admin.index');

    Route::patch('/admin/articles/{article}/toggle', [AdminController::class, 'togglePublication'])
        ->name('admin.articles.toggle');

    Route::delete('/admin/articles/{article}', [AdminController::class, 'destroy'])
        ->name('admin.articles.destroy');

    Route::get('/admin/articles/{article}/edit', [AdminController::class, 'edit'])
        ->name('admin.articles.edit');

    Route::put('/admin/articles/{article}', [AdminController::class, 'update'])
        ->name('admin.articles.update');

    Route::get('/admin/users', [UserController::class, 'index'])
        ->name('admin.users');

    Route::patch('/admin/users/{user}/role', [UserController::class, 'updateRole'])
        ->name('admin.users.role');
});
