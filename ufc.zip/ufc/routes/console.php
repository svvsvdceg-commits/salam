<?php

use App\Models\User;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('ufc:promote {email : Email зарегистрированного пользователя}', function () {
    $user = User::where('email', $this->argument('email'))->first();
    if (! $user) {
        $this->error('Пользователь не найден. Сначала зарегистрируйтесь на сайте в этой базе данных.');

        return 1;
    }

    $user->role = 'admin';
    $user->save();
    $this->info('Пользователю '.$user->email.' назначена роль администратора.');

    return 0;
})->purpose('Назначить администратора через локальную консоль');
