<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index(Request $request)
    {
        return $this->listing($request);
    }

    public function category(Request $request, string $category)
    {
        $section = Category::where('slug', $category)->first()
            ?? Category::where('name', $category)->firstOrFail();

        return $this->listing($request, $section);
    }

    private function listing(Request $request, ?Category $category = null)
    {
        $validated = $request->validate(['search' => 'nullable|string|max:255']);
        $search = trim($validated['search'] ?? '');
        $articles = Article::with(['user', 'category'])->where('status', 'published')
            ->when($category !== null, fn ($query) => $query->where('category_id', $category->id))
            ->when($search !== '', fn ($query) => $query->where('title', 'like', '%'.$search.'%'))
            ->orderByRaw('COALESCE(published_at, created_at) DESC')
            ->orderByDesc('id')
            ->get();

        return view('articles.index', compact('articles', 'search', 'category'));
    }

    public function show(string $slug)
    {
        $article = Article::with(['user', 'category'])->where('slug', $slug)
            ->where('status', 'published')
            ->firstOrFail();

        return view('articles.show', compact('article'));
    }
}
