<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class JournalistController extends Controller
{
    public function create()
    {
        $articles = Article::with(['user', 'category'])->latest()->get();

        $categories = Category::orderBy('id')->get();

        return view('journalist.create', compact('articles', 'categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'required|integer|exists:categories,id',
            'image' => 'nullable|url|max:255',
            'image_file' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp|max:5120',
            'status' => 'sometimes|required|in:draft,published,archived',
            'excerpt' => 'nullable|string',
            'content' => 'required|string',
        ]);

        $baseSlug = Str::slug($validated['title']) ?: 'news';
        $slug = $baseSlug;
        $counter = 2;
        while (Article::where('slug', $slug)->exists()) {
            $slug = $baseSlug.'-'.$counter++;
        }

        Article::create([
            'title' => $validated['title'],
            'slug' => $slug,
            'category_id' => $validated['category_id'],
            'image' => $validated['image'] ?? null,
            'excerpt' => $validated['excerpt'] ?? null,
            'content' => $validated['content'],
            'author' => $request->user()->name,
            'user_id' => $request->user()->id,
            'published_at' => ($validated['status'] ?? 'published') === 'published' ? now() : null,
            'image_path' => $request->file('image_file')?->store('articles', 'public'),
            'status' => $validated['status'] ?? 'published',
        ]);

        return redirect()
            ->route('journalist.create')
            ->with('success', ($validated['status'] ?? 'published') === 'published' ? 'Статья успешно опубликована!' : 'Статья сохранена.');
    }
}
