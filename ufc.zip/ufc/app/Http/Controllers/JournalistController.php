<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class JournalistController extends Controller
{
    public function create()
{
    $articles = \App\Models\Article::latest()->get();

    return view('journalist.create', compact('articles'));
}

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'image' => 'nullable|url|max:255',
            'excerpt' => 'nullable|string',
            'content' => 'required|string',
        ]);

        Article::create([
            'title' => $validated['title'],
            'slug' => Str::slug($validated['title']) . '-' . Str::random(6),
            'category' => $validated['category'],
            'image' => $validated['image'] ?? null,
            'excerpt' => $validated['excerpt'] ?? null,
            'content' => $validated['content'],
            'author' => 'Журналист',
            'is_published' => true,
        ]);

        return redirect()
            ->route('journalist.create')
            ->with('success', 'Статья успешно опубликована!');
    }
}
