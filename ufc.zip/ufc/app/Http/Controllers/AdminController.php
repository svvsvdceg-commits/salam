<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
    public function index()
    {
        $articles = Article::with(['user', 'category'])->latest()->get();

        return view('admin.index', compact('articles'));
    }

    public function edit(Article $article)
    {
        $categories = Category::orderBy('id')->get();

        return view('admin.edit', compact('article', 'categories'));
    }

    public function update(Request $request, Article $article)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'required|integer|exists:categories,id',
            'image' => 'nullable|url|max:255',
            'image_file' => 'nullable|image|mimes:jpg,jpeg,png,gif,webp|max:5120',
            'status' => 'sometimes|required|in:draft,published,archived',
            'excerpt' => 'nullable|string',
            'content' => 'required|string',
        ]);

        $previousImagePath = $article->image_path;
        $imagePath = $previousImagePath;
        if ($request->hasFile('image_file')) {
            $imagePath = $request->file('image_file')->store('articles', 'public');
        } elseif (($validated['image'] ?? null) !== $article->image) {
            $imagePath = null;
        }

        $status = $validated['status'] ?? $article->status;
        $article->update([
            'title' => $validated['title'],
            'category_id' => $validated['category_id'],
            'status' => $status,
            'published_at' => $status === 'published' ? ($article->published_at ?? now()) : $article->published_at,
            'image' => $validated['image'] ?? null,
            'image_path' => $imagePath,
            'excerpt' => $validated['excerpt'] ?? null,
            'content' => $validated['content'],
        ]);

        if ($previousImagePath && $previousImagePath !== $imagePath) {
            Storage::disk('public')->delete($previousImagePath);
        }

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость успешно обновлена.');
    }

    public function togglePublication(Article $article)
    {
        $article->status = $article->status === 'published' ? 'archived' : 'published';
        if ($article->status === 'published' && ! $article->published_at) {
            $article->published_at = now();
        }
        $article->save();

        return redirect()
            ->route('admin.index')
            ->with('success', 'Статус публикации изменён.');
    }

    public function destroy(Article $article)
    {
        $imagePath = $article->image_path;
        $article->delete();
        if ($imagePath) {
            Storage::disk('public')->delete($imagePath);
        }

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость удалена.');
    }
}
