<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index()
    {
        $users = User::latest()->get();

        return view('admin.users', compact('users'));
    }

    public function updateRole(Request $request, User $user)
    {
        $validated = $request->validate([
            'role' => ['required', Rule::in(['user', 'journalist', 'admin'])],
        ]);

        $user->role = $validated['role'];
        $user->save();

        return redirect()
            ->route('admin.users')
            ->with('success', 'Роль пользователя изменена.');
    }
}
