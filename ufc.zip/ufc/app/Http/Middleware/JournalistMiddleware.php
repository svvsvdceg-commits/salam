<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class JournalistMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless(in_array($request->user()?->role, ['journalist', 'admin'], true), 403,
            'Доступ разрешён только журналистам и администраторам.');

        return $next($request);
    }
}
