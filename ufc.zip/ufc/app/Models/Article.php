<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Article extends Model
{
    use HasFactory;

    public const STATUSES = [
        'draft' => 'Черновик',
        'published' => 'Опубликована',
        'archived' => 'В архиве',
    ];

    protected $fillable = [
        'title',
        'slug',
        'excerpt',
        'content',
        'image',
        'category_id',
        'author',
        'status',
        'user_id',
        'published_at',
        'image_path',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function getAuthorNameAttribute(): string
    {
        return $this->user?->name ?? $this->author;
    }

    public function getImageUrlAttribute(): ?string
    {
        return $this->image_path ? asset('storage/'.$this->image_path) : $this->image;
    }

    protected function casts(): array
    {
        return [
            'published_at' => 'datetime',
        ];
    }
}
