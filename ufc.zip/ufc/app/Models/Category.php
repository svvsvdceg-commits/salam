<?php

namespace App\Models;

use Database\Factories\CategoryFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    /** @use HasFactory<CategoryFactory> */
    use HasFactory;

    public const DEFAULTS = [
        'ufc' => 'UFC',
        'fights' => 'Поединки',
        'fighters' => 'Бойцы',
        'rankings' => 'Рейтинги',
        'mma' => 'MMA',
    ];

    protected $fillable = ['name', 'slug'];

    public function articles(): HasMany
    {
        return $this->hasMany(Article::class);
    }
}
