<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('slug')->unique();
            $table->timestamps();
        });

        $defaults = [
            'ufc' => 'UFC', 'fights' => 'Поединки', 'fighters' => 'Бойцы',
            'rankings' => 'Рейтинги', 'mma' => 'MMA',
        ];
        foreach ($defaults as $slug => $name) {
            DB::table('categories')->insert([
                'name' => $name, 'slug' => $slug, 'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        Schema::table('articles', function (Blueprint $table) {
            $table->foreignId('category_id')->nullable()->constrained()->restrictOnDelete();
            $table->enum('status', ['draft', 'published', 'archived'])->default('published')->index();
        });

        foreach (DB::table('articles')->select('category')->distinct()->get() as $article) {
            $name = $article->category;
            $categoryId = DB::table('categories')->where('name', $name)->value('id');
            if (! $categoryId) {
                $baseSlug = Str::slug($name) ?: 'category';
                $slug = $baseSlug;
                $counter = 2;
                while (DB::table('categories')->where('slug', $slug)->exists()) {
                    $slug = $baseSlug.'-'.$counter++;
                }
                $categoryId = DB::table('categories')->insertGetId([
                    'name' => $name, 'slug' => $slug, 'created_at' => now(), 'updated_at' => now(),
                ]);
            }
            DB::table('articles')->where('category', $name)->update(['category_id' => $categoryId]);
        }
        DB::table('articles')->where('is_published', false)->update(['status' => 'archived']);

        Schema::table('articles', function (Blueprint $table) {
            $table->unsignedBigInteger('category_id')->nullable(false)->change();
            $table->dropColumn(['category', 'is_published']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('articles', function (Blueprint $table) {
            $table->string('category')->default('UFC');
            $table->boolean('is_published')->default(true);
        });
        foreach (DB::table('categories')->get() as $category) {
            DB::table('articles')->where('category_id', $category->id)->update(['category' => $category->name]);
        }
        DB::table('articles')->where('status', '!=', 'published')->update(['is_published' => false]);
        Schema::table('articles', function (Blueprint $table) {
            $table->dropForeign(['category_id']);
            $table->dropIndex(['status']);
            $table->dropColumn(['category_id', 'status']);
        });
        Schema::dropIfExists('categories');
    }
};
