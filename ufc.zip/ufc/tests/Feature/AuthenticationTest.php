<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Category;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_guests_can_open_auth_forms_and_register_only_as_readers(): void
    {
        $this->get('/')->assertOk()->assertSee('Регистрация')->assertDontSee('>Админ<', false);
        $this->get('/login')->assertOk()->assertSee('Вход в аккаунт');
        $this->get('/register')->assertOk()->assertSee('Повторите пароль');
        $this->post('/register', [
            'name' => 'Читатель', 'email' => 'reader@example.test',
            'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'admin',
        ])->assertRedirect('/');
        $user = User::firstOrFail();
        $this->assertAuthenticatedAs($user);
        $this->assertSame('user', $user->role);
        $this->assertTrue(Hash::check('password123', $user->password));
        $this->get('/')->assertSee('Регистрация прошла успешно!')->assertSee('Читатель')->assertSee('Выйти');
        $this->get('/login')->assertRedirect('/');
        $this->get('/register')->assertRedirect('/');
    }

    public function test_registration_rejects_duplicate_email_and_unconfirmed_short_password(): void
    {
        User::factory()->create(['email' => 'reader@example.test']);
        $this->post('/register', [
            'name' => '', 'email' => 'reader@example.test',
            'password' => 'short', 'password_confirmation' => 'different',
        ])->assertSessionHasErrors(['name', 'email', 'password']);
        $this->assertGuest();
        $this->assertDatabaseCount('users', 1);
    }

    public function test_login_rejects_wrong_password_and_restores_intended_page_then_logout_revokes_access(): void
    {
        $user = User::factory()->create(['role' => 'admin']);
        $this->get('/admin')->assertRedirect('/login');
        $this->from('/login')->post('/login', ['email' => $user->email, 'password' => 'incorrect'])
            ->assertRedirect('/login')->assertSessionHasErrors('email');
        $this->assertGuest();
        $this->post('/login', ['email' => $user->email, 'password' => 'password'])->assertRedirect('/admin');
        $this->assertAuthenticatedAs($user);
        $this->get('/admin')->assertOk();
        $this->post('/logout')->assertRedirect('/');
        $this->assertGuest();
        $this->get('/admin')->assertRedirect('/login');
    }

    public function test_guest_and_reader_cannot_use_any_staff_endpoint(): void
    {
        $article = Article::create([
            'title' => 'Новость', 'slug' => 'news', 'category_id' => Category::where('name', 'UFC')->firstOrFail()->id,
            'content' => 'Текст', 'author' => 'Редакция', 'status' => 'published',
        ]);
        $user = User::factory()->create();
        $endpoints = [
            ['GET', '/journalist'], ['POST', '/journalist'], ['GET', '/admin'],
            ['GET', "/admin/articles/{$article->id}/edit"], ['PUT', "/admin/articles/{$article->id}"],
            ['PATCH', "/admin/articles/{$article->id}/toggle"], ['DELETE', "/admin/articles/{$article->id}"],
            ['GET', '/admin/users'], ['PATCH', "/admin/users/{$user->id}/role"],
        ];
        foreach ($endpoints as [$method, $url]) {
            $this->call($method, $url)->assertRedirect('/login');
        }
        $this->actingAs($user);
        foreach ($endpoints as [$method, $url]) {
            $this->call($method, $url)->assertForbidden();
        }
        $this->get('/')->assertDontSee('>Админ<', false)->assertDontSee('>Журналист<', false);
        $this->assertDatabaseHas('articles', ['id' => $article->id, 'status' => 'published']);
        $this->assertSame('user', $user->fresh()->role);
    }

    public function test_journalist_can_publish_but_cannot_manage_articles_or_roles(): void
    {
        $journalist = User::factory()->create(['role' => 'journalist']);
        $this->actingAs($journalist);
        $this->post('/journalist', ['title' => 'Новость', 'category_id' => Category::where('name', 'UFC')->firstOrFail()->id, 'content' => 'Текст'])
            ->assertRedirect('/journalist');
        $article = Article::firstOrFail();
        $this->get('/journalist')->assertOk()->assertDontSee('Редактировать');
        $this->get('/')->assertSee('>Журналист<', false)->assertDontSee('>Админ<', false);
        $this->get('/admin')->assertForbidden();
        $this->get("/admin/articles/{$article->id}/edit")->assertForbidden();
        $this->put("/admin/articles/{$article->id}", [])->assertForbidden();
        $this->patch("/admin/articles/{$article->id}/toggle")->assertForbidden();
        $this->delete("/admin/articles/{$article->id}")->assertForbidden();
        $this->get('/admin/users')->assertForbidden();
        $this->patch("/admin/users/{$journalist->id}/role", ['role' => 'admin'])->assertForbidden();
        $this->assertSame('journalist', $journalist->fresh()->role);
    }

    public function test_repeated_login_attempts_are_throttled(): void
    {
        for ($attempt = 0; $attempt < 6; $attempt++) {
            $this->post('/login', ['email' => 'unknown@example.test', 'password' => 'wrong'])->assertRedirect();
        }
        $this->post('/login', ['email' => 'unknown@example.test', 'password' => 'wrong'])->assertStatus(429);
    }

    public function test_local_command_can_promote_an_existing_account(): void
    {
        $user = User::factory()->create();
        $this->artisan('ufc:promote', ['email' => $user->email])->assertSuccessful();
        $this->assertSame('admin', $user->fresh()->role);
        $this->actingAs($user->fresh())->get('/admin/users')->assertOk();
    }

    public function test_local_command_does_not_create_an_account_for_an_unknown_email(): void
    {
        $this->artisan('ufc:promote', ['email' => 'missing@example.test'])->assertFailed();
        $this->assertDatabaseCount('users', 0);
    }
}
