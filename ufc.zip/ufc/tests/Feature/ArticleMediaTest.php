<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Category;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ArticleMediaTest extends TestCase
{
    use RefreshDatabase;

    private function photo(): UploadedFile
    {
        return UploadedFile::fake()->createWithContent('photo.png', base64_decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII='
        ));
    }

    private function payload(array $attributes = []): array
    {
        return $attributes + ['title' => 'UFC report', 'category_id' => Category::where('name', 'UFC')->firstOrFail()->id, 'content' => 'Report content'];
    }

    public function test_upload_is_saved_and_displayed_with_the_authenticated_author(): void
    {
        Storage::fake('public');
        $author = User::factory()->create(['role' => 'journalist', 'name' => 'Actual Author']);
        $this->actingAs($author)->post(route('journalist.store'), $this->payload([
            'image_file' => $this->photo(), 'user_id' => 999, 'author' => 'Forged Author',
        ]))->assertSessionHasNoErrors()->assertRedirect(route('journalist.create'));
        $article = Article::firstOrFail();
        $this->assertSame($author->id, $article->user_id);
        $this->assertTrue($article->user->is($author));
        $this->assertTrue($author->articles->first()->is($article));
        $this->assertNotNull($article->published_at);
        Storage::disk('public')->assertExists($article->image_path);
        $this->get(route('home'))->assertOk()->assertSee('Actual Author')->assertSee($article->image_url);
        $this->get(route('article.show', $article->slug))->assertOk()->assertSee('Actual Author')->assertSee($article->image_url);
    }

    public function test_invalid_and_oversized_uploads_do_not_create_articles(): void
    {
        Storage::fake('public');
        $this->actingAs(User::factory()->create(['role' => 'journalist']));
        foreach ([UploadedFile::fake()->create('document.txt', 1, 'text/plain'), $this->photo()->size(5121)] as $file) {
            $this->post(route('journalist.store'), $this->payload(['image_file' => $file]))->assertSessionHasErrors('image_file');
        }
        $this->assertDatabaseCount('articles', 0);
        $this->assertSame([], Storage::disk('public')->allFiles());
    }

    public function test_edit_preserves_or_replaces_the_photo_and_delete_cleans_up(): void
    {
        Storage::fake('public');
        $author = User::factory()->create(['role' => 'journalist']);
        $this->actingAs($author)->post(route('journalist.store'), $this->payload(['image_file' => $this->photo()]));
        $article = Article::firstOrFail();
        $originalPath = $article->image_path;
        $publicationDate = $article->published_at->toDateTimeString();
        $this->actingAs(User::factory()->create(['role' => 'admin']));
        $this->put(route('admin.articles.update', $article), $this->payload())->assertSessionHasNoErrors();
        $this->assertSame($originalPath, $article->fresh()->image_path);
        Storage::disk('public')->assertExists($originalPath);
        $this->put(route('admin.articles.update', $article), $this->payload(['image_file' => $this->photo()]))->assertSessionHasNoErrors();
        $newPath = $article->fresh()->image_path;
        $this->assertNotSame($originalPath, $newPath);
        Storage::disk('public')->assertMissing($originalPath);
        Storage::disk('public')->assertExists($newPath);
        $this->assertSame($author->id, $article->fresh()->user_id);
        $this->assertSame($publicationDate, $article->fresh()->published_at->toDateTimeString());
        $this->delete(route('admin.articles.destroy', $article))->assertRedirect(route('admin.index'));
        Storage::disk('public')->assertMissing($newPath);
    }

    public function test_url_can_replace_uploaded_photo_and_legacy_articles_still_render(): void
    {
        Storage::fake('public');
        $this->actingAs(User::factory()->create(['role' => 'admin']));
        $this->post(route('journalist.store'), $this->payload(['image_file' => $this->photo()]));
        $article = Article::firstOrFail();
        $path = $article->image_path;
        $this->put(route('admin.articles.update', $article), $this->payload(['image' => 'https://example.com/photo.jpg']))->assertSessionHasNoErrors();
        $this->assertNull($article->fresh()->image_path);
        Storage::disk('public')->assertMissing($path);
        $this->assertSame('https://example.com/photo.jpg', $article->fresh()->image_url);
        $article->refresh();
        $article->update(['user_id' => null, 'author' => 'Legacy Author', 'published_at' => null]);
        $this->get(route('article.show', $article->slug))->assertOk()->assertSee('Legacy Author')->assertSee('https://example.com/photo.jpg');
    }

    public function test_listing_uses_publication_date_instead_of_creation_date(): void
    {
        Article::create($this->payload(['title' => 'Older publication']) + ['slug' => 'older', 'published_at' => now()->subDays(2)]);
        Article::create($this->payload(['title' => 'Recent publication']) + ['slug' => 'recent', 'published_at' => now()->subDay()]);
        $this->get(route('home'))->assertOk()->assertSeeInOrder(['Recent publication', 'Older publication']);
    }
}
