<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Category;
use App\Models\User;
use Database\Seeders\CategorySeeder;
use Database\Seeders\UfcDemoSeeder;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class ArticleDatabaseTest extends TestCase
{
    use DatabaseMigrations;

    private function payload(array $attributes = []): array
    {
        return $attributes + [
            'title' => 'New report', 'category_id' => Category::firstOrFail()->id,
            'content' => 'Report content',
        ];
    }

    public function test_categories_drive_navigation_forms_and_both_url_formats(): void
    {
        $category = Category::factory()->create(['name' => 'New Section', 'slug' => 'new-section']);
        $article = Article::factory()->create(['category_id' => $category->id, 'title' => 'Section report']);
        $this->assertTrue($article->category->is($category));
        $this->assertTrue($category->articles->first()->is($article));
        $this->get('/')->assertOk()->assertSee('New Section')->assertSee(route('category', 'new-section'));
        $this->get(route('category', 'new-section'))->assertOk()->assertSee('Section report');
        $this->get(route('category', 'New Section'))->assertOk()->assertSee('Section report');
        $this->get(route('category', 'unknown-section'))->assertNotFound();
        $this->actingAs(User::factory()->create(['role' => 'journalist']));
        $this->get(route('journalist.create'))->assertOk()->assertSee('New Section')->assertSee('name="category_id"', false);
    }

    public function test_requests_reject_missing_categories_and_unknown_statuses(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'admin']));
        $this->post(route('journalist.store'), $this->payload(['category_id' => 99999]))->assertSessionHasErrors('category_id');
        $this->post(route('journalist.store'), $this->payload(['status' => 'invalid']))->assertSessionHasErrors('status');
        $this->assertDatabaseCount('articles', 0);
        $article = Article::factory()->create();
        $this->put(route('admin.articles.update', $article), $this->payload(['category_id' => 99999]))->assertSessionHasErrors('category_id');
        $this->put(route('admin.articles.update', $article), $this->payload(['status' => 'invalid']))->assertSessionHasErrors('status');
        $this->assertSame('published', $article->fresh()->status);
    }

    public function test_drafts_and_archived_articles_are_private_and_admin_can_publish_them(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'journalist']));
        foreach (['draft', 'archived'] as $status) {
            $this->post(route('journalist.store'), $this->payload(['title' => 'Private '.$status, 'status' => $status]))
                ->assertSessionHasNoErrors()->assertRedirect(route('journalist.create'));
            $article = Article::where('status', $status)->firstOrFail();
            $this->assertNull($article->published_at);
            $this->get(route('home'))->assertDontSee($article->title);
            $this->get(route('category', $article->category->slug))->assertDontSee($article->title);
            $this->get(route('article.show', $article->slug))->assertNotFound();
        }
        $article = Article::where('status', 'draft')->firstOrFail();
        $slug = $article->slug;
        $this->actingAs(User::factory()->create(['role' => 'admin']));
        $this->travelTo(now()->startOfSecond());
        $this->put(route('admin.articles.update', $article), $this->payload(['status' => 'published']))->assertSessionHasNoErrors();
        $article->refresh();
        $this->assertSame($slug, $article->slug);
        $this->assertTrue($article->published_at->equalTo(now()));
        $this->get(route('article.show', $slug))->assertOk();
        $publishedAt = $article->published_at->toDateTimeString();
        $this->put(route('admin.articles.update', $article), $this->payload(['status' => 'archived']))->assertSessionHasNoErrors();
        $this->get(route('article.show', $slug))->assertNotFound();
        $this->travel(1)->days();
        $this->patch(route('admin.articles.toggle', $article))->assertRedirect(route('admin.index'));
        $this->assertSame($publishedAt, $article->fresh()->published_at->toDateTimeString());
        $this->get(route('article.show', $slug))->assertOk();
        $this->travelBack();
    }

    public function test_duplicate_titles_receive_unique_readable_slugs(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'journalist']));
        for ($number = 0; $number < 2; $number++) {
            $this->post(route('journalist.store'), $this->payload())->assertSessionHasNoErrors();
        }
        $this->assertSame(['new-report', 'new-report-2'], Article::orderBy('id')->pluck('slug')->all());
    }

    public function test_database_prevents_deleting_a_category_used_by_articles(): void
    {
        $article = Article::factory()->create();
        $this->expectException(QueryException::class);
        $article->category->delete();
    }

    public function test_category_name_and_slug_are_unique_in_the_database(): void
    {
        $category = Category::factory()->create();
        $this->expectException(QueryException::class);
        Category::factory()->create(['slug' => $category->slug]);
    }

    public function test_seeders_are_idempotent_and_keep_existing_content(): void
    {
        $this->seed(CategorySeeder::class);
        $this->seed(UfcDemoSeeder::class);
        $article = Article::where('slug', 'demo-ufc-events')->firstOrFail();
        $article->update(['title' => 'User edited demo']);
        $this->seed(CategorySeeder::class);
        $this->seed(UfcDemoSeeder::class);
        $this->assertDatabaseCount('categories', 5);
        $this->assertDatabaseCount('articles', 3);
        $this->assertSame('User edited demo', $article->fresh()->title);
    }

    public function test_migration_preserves_legacy_articles_categories_and_visibility(): void
    {
        $migration = require database_path('migrations/2026_11_01_173813_normalize_article_categories_and_status.php');
        $migration->down();
        $legacy = [
            'title' => 'Legacy report', 'slug' => 'legacy-report', 'content' => 'Original text',
            'category' => 'Legacy Section', 'author' => 'Original Author', 'image' => 'https://example.com/photo.jpg',
            'is_published' => false, 'created_at' => now(), 'updated_at' => now(),
        ];
        $id = DB::table('articles')->insertGetId($legacy);
        $migration->up();
        $article = Article::with('category')->findOrFail($id);
        $this->assertSame('Legacy Section', $article->category->name);
        $this->assertSame('archived', $article->status);
        $this->assertSame('Original Author', $article->author_name);
        $this->assertSame('Original text', $article->content);
        $this->assertSame('https://example.com/photo.jpg', $article->image_url);
        $this->assertFalse(Schema::hasColumn('articles', 'category'));
        $this->assertFalse(Schema::hasColumn('articles', 'is_published'));
        $migration->down();
        $this->assertDatabaseHas('articles', ['id' => $id, 'category' => 'Legacy Section', 'is_published' => false]);
        $migration->up();
        $this->assertDatabaseHas('articles', ['id' => $id, 'status' => 'archived']);
    }
}
